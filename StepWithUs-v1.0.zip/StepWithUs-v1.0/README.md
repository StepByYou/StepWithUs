# StepWithUs v1.0

Negozio demo per e-book di crescita personale, produttività, AI, nutrizione ed economia globale.

## Contenuto
- Home aggiornata con immagine promozionale
- Catalogo di 5 e-book coerenti con il brand
- Carrello con localStorage
- Login demo
- Checkout demo
- Area personale "I miei e-book"
- Regole Firestore di base per una futura integrazione reale

## Come pubblicare su GitHub Pages
Carica tutti i file di questa cartella nel repository GitHub e fai commit su `main`.
GitHub Pages pubblicherà il sito entro pochi minuti.

## Prossimi step
1. Creare PDF reali.
2. Sostituire `ebooks/demo-ebook.txt` con file reali.
3. Collegare Stripe/PayPal con backend o funzioni serverless.
4. Usare Firebase Auth reale al posto del login demo.
